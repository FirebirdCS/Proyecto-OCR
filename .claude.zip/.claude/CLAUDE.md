# OCR platform — project context

Sales-incentive platform. Users photograph receipts/invoices, OCR pulls the text,
and products found there score points against campaigns an admin defines.
Firebase project: **proyecto-ocr-d3ecd**.

This file is read automatically at the start of a Claude Code session. It records
decisions and state that the code and git history do not explain on their own.

---

## State as of 2026-09-15

`master` has one commit (`0d484aa Project base added`). The receipt scoring and
the admin dashboard described below were added after it and are **uncommitted**.

Added 2026-09-15, verified only offline:

- Workspace builds clean again (`pnpm build`) with scoring and the dashboard in.
- The receipt matcher (`utils/receiptMatching.ts`) passed 21/21 cases in a
  throwaway script: quantity formats, above/below quantity lines, fuzzy names,
  SKUs, longest-match-wins. The script lived in the session scratchpad, not the repo.
- **Not exercised against live Firebase or Vision.** No real scan has scored
  points, no `salesDaily` doc has been written, and the dashboard has never
  rendered with real data. Nothing has been checked visually in a browser.

Done and verified (2026-08-26):

- Full workspace builds clean (`pnpm build`, both packages).
- `client/.env` carries the real Firebase web config; verified it inlines into
  the built bundle.
- ~~`server/serviceAccount.json` is in place and authenticates~~ — **gone as of
  2026-09-15** (not in the working tree; it is git-ignored, so the commit never
  had it). Every authenticated request then 401s with "Invalid or expired token",
  because `verifyIdToken` cannot load credentials. Re-download it (SETUP.md, step 5).
  `requireAuth` now logs the real cause in development.
- Every route returns 401 unauthenticated; unknown routes 404.
- Campaign validation checked with a throwaway script: 14/14 assertions passed
  (the script was deleted afterwards).

Not done:

- **No admin account exists yet.** There is no sign-up page, so the first one must
  come from `pnpm user:create <email> admin "<name>"`.
- `BOOTSTRAP_ADMIN_EMAILS` is empty in `server/.env`.
- SMTP is unconfigured (`SMTP_HOST` empty), so invites are not emailed — the
  invite link is returned by the API and shown in the admin panel instead.
- `firestore.rules` / `firestore.indexes.json` are written but **not deployed**.
  Until they are, campaign and product queries fail with a create-index link.
- Unverified from here: whether the Firestore database was created and whether
  Email/Password sign-in was enabled in the console. Both are user-side steps in
  `SETUP.md`. Do not assume either is done.
- Nothing has been exercised against live Firebase — no real sign-in, no invite
  delivery, no Firestore read/write.

---

## Stack

pnpm 11.15.1 workspaces · Node 25 · TypeScript 5.8 (ESM)

- **server** — Express 5, firebase-admin 13, Zod 3, `@google-cloud/vision` 5,
  nodemailer 7, multer, helmet. `module: NodeNext`, so **relative imports carry a
  `.js` extension** even though the sources are `.ts`.
- **client** — React 19, Vite 6, React Router 7, firebase 11.
  `moduleResolution: bundler`.

---

## How roles work

Two roles only: `admin` and `user` (`server/src/types/roles.ts`).

**Firebase Auth custom claims are the single source of truth.** The role is
mirrored into `users/{uid}` in Firestore, but only so admins can list and search
accounts — never read the mirror to make an authorization decision.

The claim was chosen over a Firestore-only role because one value is then
enforceable in three places with no extra read per request:

1. the API, via `requireAuth` decoding the Bearer ID token,
2. Firestore rules, via `request.auth.token.role`,
3. the React client, via the decoded token in `AuthContext`.

`BOOTSTRAP_ADMIN_EMAILS` is the escape hatch: those addresses are re-granted
admin on sign-in, so a cleared claim can never lock everyone out.

**Claims take up to an hour to propagate.** After changing a role, the client
must force-refresh the token — `refreshRole()` in `AuthContext` does this. A role
change that "didn't work" is almost always a stale token, not a failed write.

---

## The domain

**Products** (`products`) are the scoring table: name, optional SKU, and a default
points value. A product referenced by a draft or active campaign cannot be
deleted (409) — deactivate it instead, so past campaigns keep meaning what they
meant.

**Campaigns** (`campaigns`) are the rules an admin writes: which products count,
what each is worth *in this campaign* (seeded from the product default and
retunable without touching the product), which are required and at what minimum
quantity, a ladder of point milestones with optional rewards, and which users
take part. Every participant is measured against the same ladder individually.

Lifecycle `draft → active → archived`. Archived is read-only (409 on write);
active cannot be deleted; activation is gated by `assertActivatable`, which
demands at least one product and one milestone.

`writeShape()` mirrors `products[].productId` into a flat `productIds` array
purely so `array-contains` queries work — keep the two in sync on every write.

### Rules enforced server-side, not just in the form

All of these live in `campaignInputSchema.superRefine` in
`server/src/types/campaigns.ts`, so a hand-rolled API call cannot bypass them.
The editor mirrors them for feedback; **the server is the authority**.

- `endsAt` must be after `startsAt`
- no duplicate `productId` within a campaign
- milestone ids unique
- **milestone targets strictly ascending** — otherwise clearing one rung would
  silently clear another
- a required product needs `minQuantity >= 1`
- referenced products must exist and be active

---

## Scoring a receipt

`POST /api/ocr` (`file` + `campaignId`) → `assertCanScan()` → Vision →
`scanReceipt()` in `services/scoring.service.ts`.

- **A scan is filed under exactly one campaign, and the user chooses it.** The
  client pre-selects it when only one is running. `assertCanScan` runs before
  Vision is called, so a refused scan costs nothing: the caller must be a
  participant (403 `not_participant`), and the campaign must be `active` with
  `startsAt <= now < endsAt` (409 `campaign_not_running`). Only that campaign's
  products are match candidates. Deactivated products never score.
- Points = **units × the campaign's per-unit points**.
- **Anti-nonsense checks** (`utils/receiptChecks.ts`), reported as
  `scoring.issues` with a code the client words in Spanish:
  - `no_total` and `no_date` are *blocking* (0 points). A TOTAL line needs an
    amount on it or on one of the two lines below.
  - `date_outside_campaign` is blocking. At least one printed date must fall
    between the campaign's start day and min(end day, today), in `STATS_TIME_ZONE`.
  - `unpriced_products` is *non-blocking*: a matched line with no amount (on the
    line, or on the "2 x 15.00" line its quantity came from) is dropped, and the
    rest still count.
  - Rejected scans are still saved to `documents`, with their issues, but no
    guard is written, so a better photo can be resubmitted.
- **Rows are rebuilt from word geometry** (`rebuildLines` in `ocr.service.ts`).
  Scoring reads `result.lines`, not Vision's `text`. Vision emits receipt columns
  as separate blocks, which would separate every price from its product and fail
  the price check. The page is de-rotated by the words' mean angle first.
- **Three guards per scored receipt** (`receiptGuards`, all written in the same
  transaction):
  - `file-<sha>` for the same upload;
  - `text-<sha>` for the same text;
  - `receipt-<sha>` of `date|totalCents|ticket number` (falls back to the printed
    time, then to the products × quantities). This catches a *new photo* of the
    same paper receipt, from any account. If OCR misreads a digit of the ticket
    number or the total, the guard misses it; the review queue exists for that.
- **Evidence**: every scan's file (scored or not) is kept at
  `receipts/{uid}/{documentId}.{ext}` in `FIREBASE_STORAGE_BUCKET`. The upload
  happens before the transaction, and the file is deleted if the transaction
  fails. If the upload fails, the scan still goes through, flagged
  `file_not_stored`. Admins see files through 10-minute signed URLs.
  `storage.rules` denies all browser access.
- **Review**: the admin page `/admin/comprobantes` uses `GET /api/admin/scans`
  (`?flagged=true`, `?before=` cursor), `GET /:id/file` and `POST /:id/void`.
  Voiding reverses the participant's points, units, milestone and requirements,
  and the `salesDaily` totals of the day the receipt was scanned. The guards
  are kept, so a voided receipt cannot be resubmitted.
- **Limits**: `SCAN_DAILY_LIMIT` (default 20) counts *all* scans in a rolling
  24 h, and returns 429 `daily_limit` before Vision is called. If its index is
  missing, the limit is skipped with a logged error rather than taking scanning
  down. `RECEIPT_MAX_UNITS` (default 50) caps the units one receipt counts.
- **Flags** put a receipt in the review queue without changing its score:
  - `units_capped`
  - `large_line_quantity` (a line with 10+ units)
  - `frequent_scanner` (5+ scans in 24 h)
  - `file_not_stored`
- A Firestore `FAILED_PRECONDITION` (a missing index) now returns a 503 that
  says so, instead of a bare 500.
- Verified against real Vision on 2026-09-15, with `samples/`: the ticket as a
  PNG, as a PDF, and as a 6°-tilted photo each gave 10 pts. The out-of-date ticket
  got `date_outside_campaign`, and the hand-written note got `no_total` +
  `no_date` + `unpriced_products`.
- `matchReceipt()` is pure and has no Firestore access. It matches line by line.
  Spacing, punctuation and accents are ignored, so "COCA-COLA" matches
  "Coca Cola". Names of 5+ characters tolerate one OCR typo (two at 12+). Digits
  must match exactly, so "500ml" never matches "600ml". SKUs must match exactly.
  When several products match a line, the longest one wins.
- Quantities: "2 x 15.00", "x2", "3 un", "cant: 2", or a leading "2 PRODUCT".
  A quantity-only line next to the item is used only when the receipt shows which
  side those lines sit on. **When unsure, it counts 1 unit.** Under-awarding is the
  deliberate failure mode. Keep it that way.
- Everything is written in one transaction: the document, `participants/{uid}`
  (points, units per product, milestone, `requirementsMet`), the guards and the
  `salesDaily` totals.
- Duplicates return 409. The guards hash the file and the normalized text. They
  are written only for receipts that earned points, so a receipt with no match can
  be rescanned once its campaign goes live. A *new photo* of the same paper
  receipt is **not** caught.
- `salesDaily` days are cut in `STATS_TIME_ZONE` (defaults to the server zone).
  The dashboard reads at most ~365 of these docs. It never scans `documents`.
  Every scan in a day increments the same doc, which caps sustained throughput
  around 1 scored receipt/sec. Shard it if that ever matters.
- Admins land on the stats dashboard at `/`. Users land on their campaigns and
  the scanner. Same route, and `DashboardPage` branches on role.

---

## API surface

Everything is under `/api`. `adminRouter.use(requireAuth, requireAdmin)` gates
the whole admin tree in one place — individual admin routes carry no guard of
their own, so **do not mount anything under `/api/admin` that should be public**.

| Route | Who |
| --- | --- |
| `GET /api/health` | public |
| `GET /api/me` | signed in — provisions the profile on first call |
| `POST /api/ocr` | **`user` role only**, with `file` + `campaignId`. Scores against that campaign only; admins get 403 |
| `GET /api/ocr/documents` | signed in |
| `GET /api/campaigns` | signed in — the caller's campaigns, plus their `progress` and `productNames` |
| `POST /api/mail/send` | signed in |
| `GET·POST /api/admin/users`, `POST /:uid/invite`, `PATCH /:uid/role`, `PATCH /:uid/disabled` | admin |
| `GET·POST·PATCH·DELETE /api/admin/products` | admin |
| `GET·POST /api/admin/campaigns`, `PUT /:id`, `PATCH /:id/status`, `DELETE /:id` | admin |
| `GET /api/admin/dashboard` | admin — product counts, sales per day/week/month, top sellers |
| `GET /api/admin/scans`, `GET /:id/file`, `POST /:id/void` | admin — scan review, evidence, taking points back |

`PUT /api/admin/campaigns/:id` is a **full replace**, not a merge.

---

## Firestore

Collections: `users`, `products`, `campaigns` (+ `participants` subcollection),
`documents`, `salesDaily` (one doc per calendar day, admin-readable),
`receiptGuards` (duplicate-scan fingerprints, server-only).

`.firebaserc` pins the CLI to `proyecto-ocr-d3ecd`. On 2026-09-15 the user ran
`npx firebase-tools deploy --only firestore:indexes,storage`, which deployed
every declared index (including `documents (flagged, createdAt desc)` for the
review queue) and `storage.rules`. `firestore.rules` has still not been deployed
from here. Storage: bucket `proyecto-ocr-d3ecd.firebasestorage.app`; an
upload → signed URL → delete round-trip was verified.

**Every client write is denied** (`if false`). The browser reads; all writes go
through the API with the Admin SDK, which bypasses rules entirely. This means
rules only ever need to get *reads* right — but also that a rules bug cannot be
caught by testing writes.

---

## Hosting

The two halves deploy separately: the API to Cloud Run, the client to GitHub
Pages. Neither had been deployed as of 2026-09-16 — the files exist, nothing has
been run.

**API — deployed 2026-09-16 to `https://ocr-api-3bi5lk4hta-uc.a.run.app`**
(Cloud Run service `ocr-api`, region `us-central1`, running as
`firebase-adminsdk-fbsvc@proyecto-ocr-d3ecd.iam.gserviceaccount.com`). Redeploy
with `scripts/deploy-api.ps1`; the URL is also kept in
`scripts/.last-deploy-url.txt`.

- **No key file in the image.** It runs as the Firebase Admin SDK service
  account, and firebase-admin, Firestore, Storage and Vision all use that
  identity through ADC. `GOOGLE_APPLICATION_CREDENTIALS` and `VISION_KEY_FILE`
  must stay unset there, or the server hunts for a file that is not in the image.
- **Signed URLs need `roles/iam.serviceAccountTokenCreator` on the account
  itself.** Without a local private key, `getSignedUrl` signs through the IAM
  API, so receipt evidence in the admin panel 500s without that binding.
- `app.listen(env.PORT)` already binds every interface, and Cloud Run's `PORT`
  flows through `config/env.ts`. Nothing about the server is Cloud Run specific.

**Client — `.github/workflows/pages.yml`** publishes it to
`https://firebirdcs.github.io/Proyecto-OCR/` on every push to `master`.

- **Pages cannot run the API.** Without a hosted server and `VITE_API_BASE_URL`
  set as a repository *variable*, the deployed site signs in through Firebase and
  then fails every `/api` call. The server needs a host that runs Node.
- Vite's `base` comes from `VITE_BASE` (CI sets `/<repo>/`); the router reads it
  through `import.meta.env.BASE_URL`. `404.html` is a copy of `index.html`, which
  is what makes deep links work on Pages.
- `CLIENT_ORIGIN` is now a **comma-separated list** used for CORS, and
  `CLIENT_APP_URL` (with sub-path) is what invite links are built from. They are
  no longer the same value once the app lives under `/Proyecto-OCR/`.

---

## Conventions

- Routes stay thin: validate with Zod, call a service, return. Services own all
  Firestore access.
- Domain types and their Zod schemas live together in `types/`, and the client
  mirrors them in `client/src/types/` — **changing one means changing both.**
- Errors: throw `HttpError` from `utils/httpError.ts`; `errorHandler` is the only
  place that shapes a response.
- Comments explain *why*, not *what*. Match the surrounding density.

---

## Decisions worth not relitigating

- **Google Cloud Vision for OCR.** Firebase has no OCR product. Vision runs on the
  same GCP project and shares the service-account credentials. Alternatives
  considered: the Extract Image Text extension, Tesseract.
- **No password is ever emailed.** `createUserAccount` sets a random password
  nobody sees, then sends a `generatePasswordResetLink`. If SMTP is down the
  account is still created and the link is returned in the response — it degrades
  instead of failing.
- **No registration page, by request.** The login page is sign-in plus password
  reset. Its error text is deliberately identical for a wrong password and an
  unknown address, so the form cannot be used to probe for valid emails. Keep it
  vague if you touch it.
- **Points are overridable per campaign** rather than global, so retuning a
  campaign never rewrites product history.

---

## Traps

- **pnpm 11.15.1 needs Node >= 22.13.** It loads `node:sqlite`, so on Node 20 any
  `pnpm install` dies with `ERR_UNKNOWN_BUILTIN_MODULE: node:sqlite`. This broke
  the first Cloud Run build (`.nvmrc` said 20, the image was `node:20-slim`).
  `.nvmrc` now says 22, the image is `node:22-slim`, and the Pages workflow reads
  `.nvmrc` — keep all three in step.
- **pnpm 11 ignores the `pnpm` field in `package.json`.** Install-script approvals
  live in an `allowBuilds:` map in `pnpm-workspace.yaml`. Currently allowed:
  `@firebase/util`, `esbuild`, `protobufjs`. A new `ERR_PNPM_IGNORED_BUILDS` goes
  there, not in `package.json`.
- **Empty `.env` values.** `FOO=` means "not set", not `""`. `config/env.ts`
  filters empty strings out of `process.env` before Zod parses them; removing that
  filter breaks startup on the optional URL vars.
- `localhost` must stay an authorized domain in Firebase Auth or invite links are
  rejected — the continue URL points at `http://localhost:5173/login`.
- `@types/node` in the client is a real dependency, not incidental:
  `tsconfig.node.json` sets `types: ["node"]`. npm hoisting used to hide this;
  pnpm's isolation exposed it as `TS2688`.
- Heredocs in this repo's shell keep failing on backticks and apostrophes. Write
  large files with the Write tool instead of `cat <<EOF`.

### Secrets

`client/.env` is **public by design** — it ships in the JS bundle, and access is
controlled by rules and the API, not by hiding it. Safe to discuss.

`server/serviceAccount.json` is a **real secret** granting full admin access to
the project. It is git-ignored. Never print its contents, never commit it, and
never paste it into a chat. Same for `server/.env` (SMTP password).

---

## Commands

Run from the repo root.

| Command | Does |
| --- | --- |
| `pnpm dev` | server + client together |
| `pnpm build` / `pnpm typecheck` | both packages |
| `pnpm user:create <email> <admin\|user> ["Name"]` | creates an account, prints the invite link |
| `pnpm role:grant <email> <role>` | changes a role by email |

---

## Not built yet

- **Cloud Vision API was disabled** on the GCP project as of 2026-09-15
  (`PERMISSION_DENIED … has not been used in project 802931345292`). Until it is
  enabled, every scan fails. Enabling it may require billing on the project.
  The user has since enabled it, and scans work.
- PDFs go through `extractTextFromPdf` (`batchAnnotateFiles`, first 5 pages).
  Verified on the sample PDF.
- `samples/` holds test inputs for the "Farmacia" campaign (Paracetamol, 2 pts):
  - `ticket-farmacia.{html,pdf,png}`: a valid ticket with 3 + 2 units, worth 10 pts.
    Once it has scored, a rescan gets a 409.
  - `ticket-fuera-de-fecha.{html,png}`: dated 10/07/2026, before the campaign.
    Should be rejected with `date_outside_campaign`.
  - `nota-sin-ticket.{html,png}`: a hand-written list with no price, total or
    date. Should be rejected.
  - **`samples/casos/`**: 15 cases from `samples/generate_samples.py`, one per
    scanner behaviour: quantity formats, date formats, OCR typo, phone photo,
    A4 invoice PDF, both review flags, each rejection and a duplicate. The
    expected result for each is in `samples/README.md`. They are dated relative
    to `--date` (stdlib Python + Edge only), so regenerate them whenever the
    campaign's dates change. On 2026-09-18 all 15 matched their expected result
    through real Vision + the scanner's logic, read-only.
- **QA board in Jira** (2026-09-27): `scripts/test-plan.json` is the QA plan
  built from the two university documents (ProyectoSeminario v2.1 and the
  Entregables PDF). It has 7 epics mirroring the documents' epics, 17 stories
  with acceptance criteria and HU/RF/RN/CP traceability, and 34 QA sub-tasks,
  split over the user's fixed sprints: Sprint 1 28 sep–1 oct, Sprint 2
  2–8 oct, Sprint 3 9–16 oct. **Created on 2026-09-27** in
  `afloresperezinfo.atlassian.net`, space `SCRUM` (team-managed, board 1):
  epics SCRUM-5–11, stories and sub-tasks SCRUM-12–62, stories moved into
  their sprints with story points. The keys are in `scripts/.jira-created.json`.
  SCRUM-4 was the user's own and was left alone.
  **Reorganized 2026-09-28** to follow the course guide, where each sprint is a
  QA phase: Sprint 1 = preparation, Sprint 2 = test design, Sprint 3 = manual
  execution + bugs (min. 10) + automation.
  - Sprint 1: backlog, Scrum roles, architecture, ISO 25010 attributes, metrics.
  - Sprint 2: equivalence classes and boundary values, decision tables,
    pairwise, state transitions, 12+ test cases, full test plan.
  - Sprint 3: the 17 system HUs, bug management, Jest, Cypress, JMeter, suite
    report, executive presentation.
  - New epics SCRUM-63–66 and stories/sub-tasks SCRUM-67–110. Totals:
    11 epics, 35 stories, 60 sub-tasks; points 10 / 15 / 62, so Sprint 3 is heavy.
  - Still to configure by hand in Jira: a Bug ("Error") issue type with
    Severidad and Clasificación (error/defecto/fallo) fields, and a bug workflow.
    The user kept the same API token on purpose. In team-managed spaces the
  board type is `simple`, and sub-tasks inherit the parent's sprint even though
  the agile API still lists them under the backlog. Acceptance criteria describe what
  the system really does. Document HUs with no implementation behind them were
  deliberately left out: 5-attempt lockout, 30-min session expiry, batch upload,
  visitador and points of sale, field correction with confidence, typed
  rejection causes, audit log, PDF/Excel export, dashboard filters by point of
  sale or collaborator, NIT/serie extraction, 15-day and 1 % rules.
- Known defects the QA plan will surface: an unsupported file type returns an
  English 400 ("Expected a file upload…"), and a file over the size limit
  returns a 500 (the MulterError is not mapped in `errorHandler`).
- No way for an admin to review or correct a scan. A misread quantity stands.
  There is also no admin view of an individual participant's progress.
- Required products are tracked (`requirementsMet`) and shown to the user, but
  they do not gate milestones. Milestones are cleared by points alone.
- **No tests of any kind**, and no test runner installed. The matcher is the
  first thing worth covering.
- No pagination anywhere; `listUsers` and `listDocuments` are capped and will need
  cursors before real volume.
